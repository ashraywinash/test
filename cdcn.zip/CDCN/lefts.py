class Grammar:
    def __init__(self, rules):
        self.rules = rules  # Dictionary of rules (e.g., {'A': ['Aa', 'b']})

    def eliminate_left_recursion(self):
        new_rules = {}
        for non_terminal in self.rules:
            alpha = []  # For direct left recursion (A -> Aα)
            beta = []   # For other rules (A -> β)
            for production in self.rules[non_terminal]:
                if production.startswith(non_terminal):  # Left recursion
                    alpha.append(production[len(non_terminal):])
                else:
                    beta.append(production)

            if alpha:  # If there is left recursion
                new_non_terminal = non_terminal + "'"
                new_rules[non_terminal] = [b + new_non_terminal for b in beta]
                new_rules[new_non_terminal] = [a + new_non_terminal for a in alpha] + ['ε']
            else:  # No left recursion
                new_rules[non_terminal] = self.rules[non_terminal]
        self.rules = new_rules

    def perform_left_factoring(self):
        new_rules = {}
        for non_terminal, productions in self.rules.items():
            prefix_map = {}
            for production in productions:
                prefix = production[0]  # Group by first character
                if prefix not in prefix_map:
                    prefix_map[prefix] = []
                prefix_map[prefix].append(production)

            # If multiple productions share the same prefix, perform factoring
            factored_rules = []
            for prefix, group in prefix_map.items():
                if len(group) > 1:
                    new_non_terminal = non_terminal + "'"
                    new_rules[new_non_terminal] = [prod[1:] if len(prod) > 1 else 'ε' for prod in group]
                    factored_rules.append(prefix + new_non_terminal)
                else:
                    factored_rules.extend(group)
            new_rules[non_terminal] = factored_rules
        self.rules = new_rules

    def __str__(self):
        return "\n".join(f"{nt} -> {' | '.join(productions)}" for nt, productions in self.rules.items())


# Test cases
if __name__ == "__main__":
    print("Test Case 1: Eliminate Left Recursion")
    grammar1 = Grammar({
        'A': ['Aa', 'b']
    })
    print("Original Grammar:")
    print(grammar1)
    grammar1.eliminate_left_recursion()
    print("\nAfter Eliminating Left Recursion:")
    print(grammar1)

    print("\nTest Case 2: Perform Left Factoring")
    grammar2 = Grammar({
        'A': ['ab', 'ac', 'd']
    })
    print("Original Grammar:")
    print(grammar2)
    grammar2.perform_left_factoring()
    print("\nAfter Performing Left Factoring:")
    print(grammar2)

    print("\nTest Case 3: Both Eliminate Left Recursion and Perform Left Factoring")
    grammar3 = Grammar({
        'S': ['Sa', 'Sb', 'c', 'd']
    })
    print("Original Grammar:")
    print(grammar3)
    grammar3.eliminate_left_recursion()
    grammar3.perform_left_factoring()
    print("\nAfter Processing:")
    print(grammar3)
