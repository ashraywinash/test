#include <iostream>
#include <vector>
#include <queue>
#include <limits>
using namespace std;

typedef pair<int, int> pii; // First: distance, Second: vertex

// Function to perform Dijkstra's algorithm
vector<int> dijkstra(int vertices, vector<vector<pii>>& graph, int source) {
    // Distance vector to store the shortest distance to each vertex
    vector<int> distances(vertices, numeric_limits<int>::max());
    distances[source] = 0;

    // Min-heap priority queue for exploring vertices by shortest distance
    priority_queue<pii, vector<pii>, greater<pii>> pq;
    pq.push({0, source}); // {distance, vertex}

    while (!pq.empty()) {
        pii current = pq.top();
        pq.pop();

        int currentDistance = current.first;
        int u = current.second;

        // If this distance is not up to date, skip
        if (currentDistance > distances[u]) continue;

        // Traverse through all adjacent vertices of u
        for (const auto& neighbor : graph[u]) {
            int v = neighbor.second;
            int weight = neighbor.first;

            // If a shorter path to v is found
            if (distances[u] + weight < distances[v]) {
                distances[v] = distances[u] + weight;
                pq.push({distances[v], v});
            }
        }
    }

    return distances;
}

int main() {
    int vertices, edges;
    cout << "Enter the number of vertices: ";
    cin >> vertices;
    cout << "Enter the number of edges: ";
    cin >> edges;

    // Create an adjacency list
    vector<vector<pii>> graph(vertices);

    cout << "Enter the edges in the format (u v w):" << endl;
    for (int i = 0; i < edges; ++i) {
        int u, v, w;
        cin >> u >> v >> w; // u: source, v: destination, w: weight
        graph[u].push_back({w, v}); // {weight, vertex}
        // For undirected graph, also add the reverse edge
        // graph[v].push_back({w, u});
    }

    int source;
    cout << "Enter the source vertex: ";
    cin >> source;

    // Run Dijkstra's algorithm
    vector<int> distances = dijkstra(vertices, graph, source);

    // Print the shortest distances
    cout << "Shortest distances from vertex " << source << ":\n";
    for (int i = 0; i < vertices; ++i) {
        cout << "Vertex " << i << ": ";
        if (distances[i] == numeric_limits<int>::max()) {
            cout << "Unreachable";
        } else {
            cout << distances[i];
        }
        cout << endl;
    }

    return 0;
}
