class LALRParser:
    def __init__(self):
        self.grammar = {
            'S': ['E'],
            'E': ['E + T', 'E - T', 'T'],
            'T': ['T * F', 'T / F', 'F'],
            'F': ['( E )', 'id']
        }
        self.terminals = ['id', '+', '-', '*', '/', '(', ')']
        self.non_terminals = ['S', 'E', 'T', 'F']
        
        # Updated actions and GOTO tables for LALR parsing
        self.action = {
            0: {'id': 'S3', '(': 'S2'},
            1: {'+': 'S4', '-': 'S5', ')': 'acc'},
            2: {'id': 'S3', '(': 'S2'},
            3: {'+': 'S4', '-': 'S5', '*': 'S6', '/': 'S7', ')': 'R2'},
            4: {'id': 'S3', '(': 'S2'},
            5: {'id': 'S3', '(': 'S2'},
            6: {'id': 'S3', '(': 'S2'},
            7: {'id': 'S3', '(': 'S2'},
            8: {'+': 'R3', '-': 'R3', '*': 'S6', '/': 'S7', ')': 'R3'},
            9: {'+': 'R4', '-': 'R4', '*': 'S6', '/': 'S7', ')': 'R4'},
            10: {'+': 'R5', '-': 'R5', '*': 'S6', '/': 'S7', ')': 'R5'}
        }

        self.goto = {
            0: {'E': 1, 'T': 2, 'F': 3},
            2: {'T': 4, 'F': 3},
            4: {'F': 5},
            6: {'F': 8},
            7: {'F': 8}
        }

    def parse(self, input_string):
        # Tokenize the input string
        tokens = input_string.split()
        tokens.append('$')  # Add EOF symbol ($) at the end
        stack = [0]  # Initialize stack with the start state
        
        index = 0
        while True:
            current_state = stack[-1]
            token = tokens[index] if index < len(tokens) else '$'  # EOF symbol
            
            # Get action from the parsing table
            if token in self.action[current_state]:
                action = self.action[current_state][token]
                
                if action == 'acc':
                    print("Parsing Successful!")
                    return True
                elif action.startswith('S'):
                    # Shift action: S<state>
                    stack.append(int(action[1:]))
                    index += 1
                    print(f"Shift to state {action[1:]}")
                elif action.startswith('R'):
                    # Reduce action: R<rule number>
                    rule_num = int(action[1:])
                    rule = self.get_rule(rule_num)
                    for _ in range(len(rule[1].split())):
                        stack.pop()
                    stack.append(self.goto[stack[-1]].get(rule[0], None))
                    print(f"Reduce by rule {rule_num}: {rule[0]} -> {rule[1]}")
            else:
                print(f"Parsing Error at {token}")
                return False

    def get_rule(self, rule_num):
        """Get the grammar rule based on rule number"""
        rules = {
            1: ('E', 'E + T'),
            2: ('E', 'E - T'),
            3: ('E', 'T'),
            4: ('T', 'T * F'),
            5: ('T', 'T / F'),
            6: ('T', 'F'),
            7: ('F', '( E )'),
            8: ('F', 'id')
        }
        return rules[rule_num]

# Sample input
input_string = "id + id * id"

parser = LALRParser()
parser.parse(input_string)
