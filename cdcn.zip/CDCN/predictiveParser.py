from collections import defaultdict

import re

def tokenize(input_string):
    token_specification = [
        ('ID', r'id'),  # Identifier
        ('PLUS', r'\+'),  # Plus symbol
        ('STAR', r'\*'),  # Multiplication symbol
        ('LPAREN', r'\('),  # Left parenthesis
        ('RPAREN', r'\)'),  # Right parenthesis
        ('END', r'\$'),  # End of input
    ]
    token_regex = '|'.join(f'(?P<{pair[0]}>{pair[1]})' for pair in token_specification)
    tokens = [match.group() for match in re.finditer(token_regex, input_string)]
    return tokens
# Function to calculate First sets
def calculate_first(grammar):
    first = defaultdict(set)
    
    def compute_first(symbol):
        if symbol not in grammar:  # Terminal
            first[symbol].add(symbol)  # Terminals should have themselves in First
            return {symbol}
        if first[symbol]:  # Already computed
            return first[symbol]
        for production in grammar[symbol]:
            for prod_symbol in production:
                if prod_symbol == symbol:  # Avoid infinite recursion
                    continue
                first[symbol].update(compute_first(prod_symbol))
                if 'ε' not in first[prod_symbol]:  # Stop if no epsilon
                    break
            else:
                first[symbol].add('ε')  # Add epsilon if all symbols derive it
        return first[symbol]
    
    # Compute First for all symbols
    for non_terminal in grammar:
        compute_first(non_terminal)
    
    # Ensure terminals also have their First sets
    for symbol in grammar.keys():
        for production in grammar[symbol]:
            for term in production:
                if term not in grammar:
                    first[term].add(term)
    
    return first

# Function to calculate Follow sets
def calculate_follow(grammar, start_symbol, first):
    follow = defaultdict(set)
    follow[start_symbol].add('$')
    def compute_follow():
        updated = False
        for non_terminal, productions in grammar.items():
            for production in productions:
                trailer = follow[non_terminal].copy()
                for symbol in reversed(production):
                    if symbol in grammar:  # Non-terminal
                        if trailer - follow[symbol]:
                            follow[symbol].update(trailer)
                            updated = True
                        if 'ε' in first[symbol]:
                            trailer.update(first[symbol] - {'ε'})
                        else:
                            trailer = first[symbol]
                    else:  # Terminal
                        trailer = {symbol}
        return updated
    while compute_follow():
        pass
    return follow

# Build Predictive Parsing Table
def build_parse_table(grammar, first, follow):
    parse_table = defaultdict(dict)
    for non_terminal, productions in grammar.items():
        for production in productions:
            for terminal in first[production[0]] - {'ε'}:
                parse_table[non_terminal][terminal] = production
            if 'ε' in first[production[0]]:
                for terminal in follow[non_terminal]:
                    parse_table[non_terminal][terminal] = production
    return parse_table

# Predictive Parser
def predictive_parser(parse_table, start_symbol, input_string):
    # Tokenize the input string
    tokens = tokenize(input_string)
    tokens.append('$')  # Ensure the end marker is added

    stack = ['$']
    stack.append(start_symbol)
    pointer = 0

    print(f"{'Stack':<20}{'Input':<20}{'Action'}")
    print('-' * 60)

    while stack:
        top = stack.pop()
        current_input = tokens[pointer]

        print(f"{''.join(stack):<20}{' '.join(tokens[pointer:]):<20}", end='')

        if top == current_input:  # Match terminal
            print(f"Match '{top}'")
            pointer += 1
        elif top in parse_table:  # Non-terminal
            if current_input in parse_table[top]:
                production = parse_table[top][current_input]
                print(f"Output {top} -> {' '.join(production) if production else 'ε'}")
                if production != ['ε']:
                    stack.extend(reversed(production))  # Push production to stack
            else:
                print(f"Error: Unexpected input '{current_input}' for non-terminal '{top}'")
                return False
        else:
            print(f"Error: Mismatched terminal '{top}' with input '{current_input}'")
            return False

    if pointer == len(tokens):
        print("Input parsed successfully!")
        return True
    else:
        print("Error: Input not fully consumed")
        return False

# Main Section
if __name__ == "__main__":
    # Define grammar
    grammar = {
        'E': [['T', 'E\'']],
        'E\'': [['+', 'T', 'E\''], ['ε']],
        'T': [['F', 'T\'']],
        'T\'': [['*', 'F', 'T\''], ['ε']],
        'F': [['(', 'E', ')'], ['id']]
    }
    start_symbol = 'E'

    # Calculate First and Follow sets
    first = calculate_first(grammar)
    follow = calculate_follow(grammar, start_symbol, first)

    # Build Parse Table
    parse_table = build_parse_table(grammar, first, follow)


    # Parse Input String
    input_string = "id+id*id"
    print("\nParsing Process:")
    predictive_parser(parse_table, start_symbol, input_string)
