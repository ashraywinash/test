#include <iostream>
#include <string>
using namespace std;

// Function for bit stuffing
string bitStuffing(const string& input) {
    string stuffedData = "";
    int count = 0;

    // Traverse through the input string
    for (char bit : input) {
        stuffedData += bit;
        if (bit == '1') {
            count++;
        } else {
            count = 0;
        }

        // If we have 5 consecutive 1's, insert a 0
        if (count == 5) {
            stuffedData += '0';
            count = 0;
        }
    }

    return stuffedData;
}

// Function to remove the stuffed bits (bit de-stuffing)
string bitDestuffing(const string& input) {
    string destuffedData = "";
    int count = 0;

    // Traverse through the input string
    for (int i = 0; i < input.length(); i++) {
        destuffedData += input[i];
        if (input[i] == '1') {
            count++;
        } else {
            count = 0;
        }

        // If a '0' follows five consecutive 1's, remove the '0'
        if (count == 5 && input[i + 1] == '0') {
            i++;  // Skip the stuffed '0'
        }
    }

    return destuffedData;
}

int main() {
    string input = "111111110101111";
    cout << "Original Data: " << input << endl;

    string stuffedData = bitStuffing(input);
    cout << "Bit Stuffed Data: " << "01111110" <<stuffedData<<"01111110" << endl;

    string destuffedData = bitDestuffing(stuffedData);
    cout << "Bit De-stuffed Data: " << destuffedData << endl;

    return 0;
}
