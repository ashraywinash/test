from collections import defaultdict

def calculate_first(grammar):
    first = defaultdict(set)
    
    def compute_first(symbol):
        if symbol not in grammar:
            return {symbol}
        if symbol in first and first[symbol]:
            return first[symbol]
        for production in grammar[symbol]:
            for prod_symbol in production:
                if prod_symbol == symbol: 
                    continue
                first[symbol].update(compute_first(prod_symbol))
                if 'ε' not in first[prod_symbol]:
                    break
            else:
                first[symbol].add('ε')
        return first[symbol]
    
    for non_terminal in grammar:
        compute_first(non_terminal)
    return first


def calculate_follow(grammar, start_symbol, first):
    follow = defaultdict(set)
    follow[start_symbol].add('$') 
    
    def compute_follow():
        updated = False
        for non_terminal, productions in grammar.items():
            for production in productions:
                trailer = follow[non_terminal].copy()
                for symbol in reversed(production):
                    if symbol in grammar: 
                        if trailer - follow[symbol]:
                            follow[symbol].update(trailer)
                            updated = True
                        if 'ε' in first[symbol]:
                            trailer.update(first[symbol] - {'ε'})
                        else:
                            trailer = first[symbol]
                    else:  
                        trailer = {symbol}
        return updated
    
    while compute_follow():
        pass
    return follow


# Sample input
grammar = {
    'E': [['T', 'E\'']],
    'E\'': [['+', 'T', 'E\''], ['ε']],
    'T': [['F', 'T\'']],
    'T\'': [['*', 'F', 'T\''], ['ε']],
    'F': [['(', 'E', ')'], ['id']]
}
start_symbol = 'E'

# Calculate First and Follow sets
first = calculate_first(grammar)
follow = calculate_follow(grammar, start_symbol, first)

# Print results
print("First:")
for non_terminal, first_set in first.items():
    print(f"{non_terminal}: {first_set}")

print("\nFollow:")
for non_terminal, follow_set in follow.items():
    print(f"{non_terminal}: {follow_set}")
