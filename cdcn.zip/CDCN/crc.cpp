#include <iostream>
#include <string>
#include <bitset>

using namespace std;

// Function to perform CRC calculation
string calculateCRC(const string& data, const string& polynomial) {
    string dividend = data;
    string divisor = polynomial;

    // Append zeros to the data equal to the size of the polynomial minus 1
    dividend.append(divisor.size() - 1, '0');

    for (int i = 0; i <= dividend.size() - divisor.size(); ++i) {
        // If the current bit is 1, perform XOR with the divisor
        if (dividend[i] == '1') {
            for (int j = 0; j < divisor.size(); ++j) {
                dividend[i + j] = dividend[i + j] == divisor[j] ? '0' : '1';
            }
        }
    }

    // The remainder is the CRC
    return dividend.substr(dividend.size() - (divisor.size() - 1));
}

int main() {
    string data = "11010011101100";     // Example data in binary
    string polynomial = "1011";         // Example polynomial in binary

    string crc = calculateCRC(data, polynomial);
    cout << "Input Data: " << data << endl;
    cout << "Polynomial: " << polynomial << endl;
    cout << "CRC: " << crc << endl;

    return 0;
}
