#include <iostream>
#include <vector>
using namespace std;

// Function for byte stuffing
vector<unsigned char> byteStuffing(const vector<unsigned char>& input) {
    vector<unsigned char> stuffedData;

    for (unsigned char byte : input) {
        if (byte == '$' || byte == '!') {
            stuffedData.push_back('#');  // Escape character
            stuffedData.push_back(byte); // The byte itself is added after escape
        } else {
            stuffedData.push_back(byte);
        }
    }

    return stuffedData;
}

// Function to remove the stuffed bytes (byte de-stuffing)
vector<unsigned char> byteDestuffing(const vector<unsigned char>& input) {
    vector<unsigned char> destuffedData;
    size_t i = 0;

    while (i < input.size()) {
        if (input[i] == '#') {
            i++;  // Skip the escape character
            destuffedData.push_back(input[i]);  // Add the original byte after removing escape
        } else {
            destuffedData.push_back(input[i]);
        }
        i++;
    }

    return destuffedData;
}

int main() {
    vector<unsigned char> input = {'$', 'A', 'B', '!', 'C', 'D', '$'};
    cout << "Original Data: ";
    for (auto byte : input) {
        printf("%c ", byte);
    }
    cout << endl;

    // Perform byte stuffing
    vector<unsigned char> stuffedData = byteStuffing(input);
    cout << "Byte Stuffed Data: ";
    for (auto byte : stuffedData) {
        printf("%c ", byte);
    }
    cout << endl;

    // Perform byte de-stuffing
    vector<unsigned char> destuffedData = byteDestuffing(stuffedData);
    cout << "Byte De-stuffed Data: ";
    for (auto byte : destuffedData) {
        printf("%c ", byte);
    }
    cout << endl;

    return 0;
}
