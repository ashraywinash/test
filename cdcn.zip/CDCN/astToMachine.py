class ASTNode:
    """A class representing a node in the Abstract Syntax Tree."""
    def __init__(self, value, left=None, right=None):
        self.value = value  # Operator or operand
        self.left = left    # Left child
        self.right = right  # Right child

class MachineCodeGenerator:
    def __init__(self):
        self.instructions = []
        self.register_counter = 0

    def generate_register(self):
        """Generate a new register."""
        reg = f"R{self.register_counter}"
        self.register_counter += 1
        return reg

    def generate_machine_code(self, node):
        """
        Traverse the AST and generate machine code.
        Returns the register containing the result of the computation.
        """
        if node is None:
            return None

        if node.left is None and node.right is None:
            # Leaf node (operand)
            reg = self.generate_register()
            self.instructions.append(f"MOV {reg}, {node.value}")
            return reg

        # Recursively generate code for left and right subtrees
        left_reg = self.generate_machine_code(node.left)
        right_reg = self.generate_machine_code(node.right)

        # Allocate a new register for the result
        result_reg = self.generate_register()

        # Generate the instruction based on the operator
        if node.value == '+':
            self.instructions.append(f"ADD {result_reg}, {left_reg}, {right_reg}")
        elif node.value == '-':
            self.instructions.append(f"SUB {result_reg}, {left_reg}, {right_reg}")
        elif node.value == '*':
            self.instructions.append(f"MUL {result_reg}, {left_reg}, {right_reg}")
        elif node.value == '/':
            self.instructions.append(f"DIV {result_reg}, {left_reg}, {right_reg}")
        else:
            raise ValueError(f"Unsupported operator: {node.value}")

        # Return the register containing the result
        return result_reg

    def display_machine_code(self):
        """Print the generated machine code."""
        print("Generated Machine Code:")
        for instruction in self.instructions:
            print(instruction)

# Test Cases
if __name__ == "__main__":
    # Example: ((a + b) * (c - d))
    ast = ASTNode(
        '*',
        left=ASTNode(
            '+',
            left=ASTNode('a'),
            right=ASTNode('b')
        ),
        right=ASTNode(
            '-',
            left=ASTNode('c'),
            right=ASTNode('d')
        )
    )

    generator = MachineCodeGenerator()
    generator.generate_machine_code(ast)
    generator.display_machine_code()

    print("\nAnother Test Case:")
    # Example: (x + y) - z
    ast2 = ASTNode(
        '-',
        left=ASTNode(
            '+',
            left=ASTNode('x'),
            right=ASTNode('y')
        ),
        right=ASTNode('z')
    )

    generator2 = MachineCodeGenerator()
    generator2.generate_machine_code(ast2)
    generator2.display_machine_code()
